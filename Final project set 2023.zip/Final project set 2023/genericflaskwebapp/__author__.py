name = 'Arunesh Gour | Shailesh Goswami'
github = 'https://github.com/Arunesh-Gour/ | https://shaileshportfolio123.netlify.app/'
