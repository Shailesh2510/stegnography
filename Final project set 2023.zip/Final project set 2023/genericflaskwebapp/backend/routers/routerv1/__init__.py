from .routes import Routes as routes

__all__ = [
   'routes',
]
