import genericflaskwebapp as app

class Routes:
   endpoints = {
      'home' : '/',
      
      'signup': '/signup',
      'login' : '/login',
      
      'logout' : '/logout',
      
      'dashboard': '/dashboard',
      
      'images' : '/images/<imagename>.png',
      
      'addimage' : '/addimage',
      'deleteimage': '/deleteimage',
      'decryptimage': '/decryptimage',
      'hideimage': '/hideimage',
      
      'deleteuser': '/deleteuser',
   }
   
   def route_webapp (webapp):
      from . import pages
      
      @webapp.route(Routes.endpoints.get('home'))
      def home (*args, **kwargs):
         return pages.home(*args, **kwargs)
      
      @webapp.route(Routes.endpoints.get('signup'), methods=['POST'])
      def signup (*args, **kwargs):
         return pages.signup(*args, **kwargs)
      
      @webapp.route(Routes.endpoints.get('deleteuser'), methods=['POST'])
      def deleteuser (*args, **kwargs):
         return pages.deleteuser(*args, **kwargs)
      
      @webapp.route(Routes.endpoints.get('login'), methods=['POST'])
      def login (*args, **kwargs):
         return pages.login(*args, **kwargs)
      
      @webapp.route(Routes.endpoints.get('logout'), methods=['GET', 'POST'])
      def logout (*args, **kwargs):
         return pages.logout(*args, **kwargs)
      
      @webapp.route(Routes.endpoints.get('images'), methods=['GET'])
      def images (*args, **kwargs):
         return pages.images(*args, **kwargs)
      
      @webapp.route(Routes.endpoints.get('addimage'), methods=['POST'])
      def addimage (*args, **kwargs):
         return pages.addimage(*args, **kwargs)
      
      @webapp.route(Routes.endpoints.get('deleteimage'), methods=['POST'])
      def deleteimage (*args, **kwargs):
         return pages.deleteimage(*args, **kwargs)
      
      @webapp.route(Routes.endpoints.get('decryptimage'), methods=['POST'])
      def decryptimage (*args, **kwargs):
         return pages.decryptimage(*args, **kwargs)
      
      @webapp.route(Routes.endpoints.get('hideimage'), methods=['POST'])
      def hideimage (*args, **kwargs):
         return pages.hideimage(*args, **kwargs)
      
      @webapp.route(Routes.endpoints.get('dashboard'))
      def dashboard (*args, **kwargs):
         return pages.dashboard(*args, **kwargs)
      
      return True
