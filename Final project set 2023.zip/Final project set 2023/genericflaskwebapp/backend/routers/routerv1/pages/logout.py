from flask import (
   redirect,
)

import genericflaskwebapp as app

@app.backend.decorators.authentication.login_required(
   app.backend.router.routes.endpoints.get('home'),
   internalredirect=True,
   success='Already logged out',
)
@app.backend.decorators.authentication.get_logged_in_user()
def logout (user=None):
   if (user):
      for image in (app.database.models.UserImage.get_images(
         username=user.username,
      ) or []):
         app.backend.functionality.ImageStorage.free(imageid=image.imageid)
   
   app.backend.functionality.Authentication.logout()
   
   return redirect(app.backend.router.routes.endpoints.get('home'))
