from flask import (
   request,
)

import genericflaskwebapp as app

@app.backend.decorators.csrf.csrf_protect()
@app.backend.decorators.authentication.login_required(
   app.backend.router.routes.endpoints.get('home'),
)
@app.backend.decorators.authentication.get_logged_in_user()
def hideimage (user=None):
   imageid = request.form.get('imageid')
   imageindex = (request.form.get('imageindex') or 0)
   
   app.backend.functionality.ImageStorage.free(imageid=imageid)
   
   return app.backend.core.redirect_internal.redirect(
      app.backend.router.routes.endpoints.get('dashboard'),
      success='Image ({0}) hidden successfully'.format(
         # imageid,
         imageindex,
      ),
   )
