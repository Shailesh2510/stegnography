from flask import (
   request,
)

import genericflaskwebapp as app

@app.backend.decorators.csrf.csrf_protect()
@app.backend.decorators.authentication.login_required(
   app.backend.router.routes.endpoints.get('home'),
)
@app.backend.decorators.authentication.get_logged_in_user()
def addimage (user=None):
   file = request.files['image']
   data = (request.form.get('data') or '').strip()
   imageindex = (request.form.get('imageindex') or 0)
   
   if (not file):
      return app.backend.core.redirect_internal.redirect(
         app.backend.router.routes.endpoints.get('dashboard'),
         error='Image not attached or empty file.',
      )
   
   result = app.backend.functionality.UserImage.create(
      username=user.username,
      imagefile=file,
      data=data,
   )
   
   if (not result[0]):
      return app.backend.core.redirect_internal.redirect(
         app.backend.router.routes.endpoints.get('dashboard'),
         error=result[1],
      )
   
   imagetoken = app.backend.functionality.ImageStorage.insert(
      imageid=result[1].imageid,
      imagebytes=result[2][0],
   )
   
   return app.backend.core.redirect_internal.redirect(
      app.backend.router.routes.endpoints.get('dashboard'),
      success='Image ({0}, data: \'{1}\') added successfully'.format(
         # imagetoken,
         imageindex,
         result[2][1],
      ),
   )
