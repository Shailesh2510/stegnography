from flask import (
   request,
)

import genericflaskwebapp as app

@app.backend.decorators.csrf.csrf_protect()
@app.backend.decorators.authentication.login_required(
   app.backend.router.routes.endpoints.get('home'),
)
@app.backend.decorators.authentication.get_logged_in_user()
def decryptimage (user=None):
   imageid = request.form.get('imageid')
   imageindex = (request.form.get('imageindex') or 0)
   
   if (app.backend.functionality.ImageStorage.is_decrypted(imageid)):
      return app.backend.core.redirect_internal.redirect(
         app.backend.router.routes.endpoints.get('dashboard'),
         success='Image ({0}) decrypted successfully'.format(
            # imageid,
            imageindex,
         ),
      )
   
   userimage = app.database.models.UserImage.get_images(
      imageid=imageid,
   )
   
   if (not userimage):
      return app.backend.core.redirect_internal.redirect(
         app.backend.router.routes.endpoints.get('dashboard'),
         error='Image not found !',
      )
   
   decrypted = app.backend.functionality.UserImage.decrypt(
      userimage=userimage,
   )
   
   if (not decrypted[0]):
      return app.backend.core.redirect_internal.redirect(
         app.backend.router.routes.endpoints.get('dashboard'),
         error=decrypted[1],
      )
   
   return app.backend.core.redirect_internal.redirect(
      app.backend.router.routes.endpoints.get('dashboard'),
      success='Image ({0}) decrypted successfully'.format(
         # imageid,
         imageindex,
      ),
   )
