from flask import (
   render_template,
)

import genericflaskwebapp as app

@app.backend.decorators.csrf.csrf_protect(
   check=False,
)
@app.backend.decorators.authentication.login_required(
   app.backend.router.routes.endpoints.get('home'),
)
@app.backend.decorators.authentication.get_logged_in_user()
@app.backend.decorators.redirect_internal.check(
   app.backend.router.routes.endpoints.get('dashboard'),
)
def dashboard (redirectiondata={}, user=None):
   images = [
      {
         'imageid': image.imageid,
         'token': app.backend.functionality.UserImage.load(image),
         'is_decrypted': app.backend.functionality.ImageStorage.is_decrypted(
            image.imageid,
         ),
         'data': app.backend.functionality.ImageStorage.get_data(
            image.imageid,
         ),
      }
      for image in (app.database.models.UserImage.get_images(
         username=user.username,
      ) or [])
   ]
   
   return render_template(
      'dashboard.html',
      success=redirectiondata.get('success'),
      error=redirectiondata.get('error'),
      user=user, images=images,
      logouturl=app.backend.router.routes.endpoints.get('logout'),
      addimageurl=app.backend.router.routes.endpoints.get('addimage'),
      deleteimageurl=app.backend.router.routes.endpoints.get('deleteimage'),
      decryptimageurl=app.backend.router.routes.endpoints.get('decryptimage'),
      hideimageurl=app.backend.router.routes.endpoints.get('hideimage'),
      deleteuserurl=app.backend.router.routes.endpoints.get('deleteuser'),
   )
