import io
from flask import (
   send_file,
)

import genericflaskwebapp as app

# @app.backend.decorators.csrf.csrf_protect()
@app.backend.decorators.authentication.login_required(
   app.backend.router.routes.endpoints.get('home'),
)
@app.backend.decorators.authentication.get_logged_in_user()
def images (imagename=None, user=None):
   result = app.backend.functionality.ImageStorage.retrieve(imagename)
   
   if (not result):
      return ('Image not found !', 404)
   
   return send_file(
      io.BytesIO(result),
      download_name=('{0}.png'.format(imagename)),
      mimetype='image/png',
   )
