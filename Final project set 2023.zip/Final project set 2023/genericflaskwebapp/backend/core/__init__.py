from .redirect_internal import Redirect_Internal as redirect_internal

__all__ = [
   'redirect_internal',
]
